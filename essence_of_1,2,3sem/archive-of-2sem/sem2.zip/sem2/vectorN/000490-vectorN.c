#include <stdio.h>
#include <stdlib.h>

int Determinant (int **A, int m, int curr, int last) {
    int i, j, k, l, znak;
    int **D, sum;
    D = (int**)malloc((m - curr) * sizeof(int*));
    for (i = 0; i < m - curr; i++) {
        D[i] = (int*)malloc((m - curr) * sizeof(int));
    }
    k = 0;
    l = 0;
    sum = 0;
    if (last == -1) {
        for (i = 0; i < m - curr; i++) {
            for (j = 0; j < m - curr; j++) {
                D[i][j] = A[i][j];
            }
        }
    } else {
        for (i = 1; i < m - curr + 1; i++) {
            for (j = 0; j < m - curr + 1; j++) {
                if (j != last) {
                    D[k][l] = A[i][j];
                    l++;
                }
            }
            k++;
            l = 0;
        }
    }
    if (curr == m - 1) {
        j = D[0][0];
        for (i = 0; i < m - curr; i++)
            free(D[i]);
        free(D);
        return j;
    }
    znak = 1;
    for (i = 0; i < m - curr; i++) {
        last = i;
        sum += znak * D[0][i] * Determinant(D, m , curr + 1, last);
        znak = -znak;
    }
    for (i = 0; i < m - curr; i++)
        free(D[i]);
    free(D);
    return sum;
}
int main() {
    int m, i, j, curr, last, k, znak;
    int **A, **C;
    scanf("%d", &m);
    A = (int**)malloc(m * sizeof(int*));
    C = (int**)malloc(m * sizeof(int*));
    for (i = 0; i < m; i++) {
        C[i] = (int*)malloc(m * sizeof(int));
    }
    for (i = 0; i < m; i++) {
        A[i] = (int*)malloc((m + 1) * sizeof(int));
        for (j = 0; j < m + 1; j++) {
            scanf("%d", &A[i][j]);
        }
    }
    znak = 1;
    for (i = 0; i <= m; i++) {
        for (j = 0; j < m; j++) {
            for (k = 0; k < i; k++) {
                C[j][k] = A[j][k];
            }
            for (k = i + 1; k <= m; k++) {
                C[j][k - 1] = A[j][k];
            }
        }
        curr = 0;
        last = -1;
        printf("%d\n", znak * Determinant(C, m, curr, last));
        znak = -znak;
    }
    for (i = 0; i < m; i++) {
        free(A[i]);
        free(C[i]);
    }
    free(A);
    free(C);
    return 0;
}
