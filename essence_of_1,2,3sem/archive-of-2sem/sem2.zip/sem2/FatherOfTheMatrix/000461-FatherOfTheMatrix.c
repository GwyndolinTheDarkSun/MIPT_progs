#include <stdio.h>
#include <math.h>

int main() {
    int a, b, c, d, e;
    scanf("%d %d %d %d", &a, &b, &c, &d);
    e = ((c - b) * d + b) % a;
    if (e < 0) {
        printf("%d\n", a + e);
    } else {
        printf("%d\n", e);
    }
    return 0;
}
