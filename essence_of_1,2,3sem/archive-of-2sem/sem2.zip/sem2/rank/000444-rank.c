#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#define cor0(x) ((x) > -1e-6 && (x) < 1e-6 ? 0 : (x))

int main() {
    int m, i, j, k, mark1, y, mark2, n, countrang;
    double **A, coef;
    scanf("%d %d", &m, &n);
    A = (double**)malloc(m * sizeof(double*));
    for (i = 0; i < m; i++) {
        A[i] = (double*)malloc(n * sizeof(double));
        for (j = 0; j < n; j++) {
            scanf("%lg", &A[i][j]);
        }
    }
    for (k = 0; k < n; k++) {
        mark1 = 0;
        mark2 = 0;
        i = 0;
        while (mark2 == 0 && i != m) {
            if (A[i][k] != 0) {
                mark2 = 1;
                for (j = 0; j < k; j++) {
                    if (A[i][j] != 0) {
                        mark2 = 0;
                    }
                }
            }
            i++;
        }
        i--;
        if (i == m - 1 && mark2 == 0) {
            mark1 = 1;
        }
        if (mark1 == 0) {
            for (j = 0; j < m; j++) {
                if (j != i) {
                    coef = A[j][k] / A[i][k];
                    for (y = 0; y < n; y++) {
                        A[j][y] = cor0(A[j][y] - coef * A[i][y]);
                    }
                }
            }
        }
    }
    countrang = 0;
    for (i = 0; i < m; i++) {
        mark2 = 0;
        j = 0;
        while (mark2 == 0 && j != n) {
            if (A[i][j] != 0) {
                mark2 = 1;
            }
            j++;
        }
        if (mark2 == 1) {
            countrang += 1;
        }
    }
    printf("%d\n", countrang);
    for (i = 0; i < m; i++)
        free(A[i]);
    free(A);
    return 0;
}
