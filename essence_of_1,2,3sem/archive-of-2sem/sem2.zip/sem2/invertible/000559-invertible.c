#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#define cor0(x) ((x) > -1e-6 && (x) < 1e-6 ? 0 : (x))

int main() {
    int m, i, j, k, mark1, mark2, y;
    double **A, **B, coef;
    scanf("%d", &m);
    mark1 = 0;
    A = (double**)malloc(m * sizeof(double*));
    B = (double**)calloc(m , sizeof(double*));
    for (i = 0; i < m; i++) {
        A[i] = (double*)malloc(m * sizeof(double));
        B[i] = (double*)calloc(m , sizeof(double));
        for (j = 0; j < m; j++) {
            scanf("%lg", &A[i][j]);
        }
    }
    for (i = 0; i < m; i++) {
        B[i][i] = 1;
    }
    for (k = 0; k < m; k++) {
        mark2 = 0;
        i = 0;
        while (mark2 == 0 && i != m) {
            if (A[i][k] != 0) {
                mark2 = 1;
                for (j = 0; j < k; j++) {
                    if (A[i][j] != 0) {
                        mark2 = 0;
                    }
                }
            }
            i++;
        }
        i--;
        if (i == m - 1 && mark2 == 0) {
            mark1 = 1;
        }
        if (mark1 == 0) {
            for (j = 0; j < m; j++) {
                if (j != i) {
                    coef = A[j][k] / A[i][k];
                    for (y = 0; y < m; y++) {
                        A[j][y] = A[j][y] - coef * A[i][y];
                    }
                    for (y = 0; y < m; y++) {
                        B[j][y] = B[j][y] - coef * B[i][y];
                    }
                }
            }
        }
    }
    if (mark1 == 0) {
        for (k = 0; k < m; k++) {
            i = 0;
            while (A[i][k] == 0) {
                i++;
            }
            for (j = 0; j < m; j++) {
                printf("%lg ", cor0(B[i][j] / A[i][k]));
            }
            if (k != m - 1) {
                printf("\n");
            }
        }
    } else {
        printf("NO\n");
    }
    for (i = 0; i < m; i++)
        free(A[i]);
    free(A);
    for (i = 0; i < m; i++)
        free(B[i]);
    free(B);
    return 0;
}
