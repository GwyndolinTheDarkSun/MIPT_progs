#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#define cor0(x) ((x) > -1e-6 && (x) < 1e-6 ? 0 : (x))

int main() {
    int m, i, j, k, y;
    /*mark1 = признак того , равен детерминант 0 или нет*/
    double **A, **B, coef;
    scanf("%d", &m);
    A = (double**)malloc(m * sizeof(double*));
    B = (double**)calloc(m , sizeof(double*));
    for (i = 0; i < m; i++) {
        A[i] = (double*)malloc(m * sizeof(double));
        B[i] = (double*)calloc(m , sizeof(double));
        B[i][i] = 1;
        for (j = 0; j < m; j++) {
            scanf("%lg", &A[i][j]);
        }
    }
    for (k = 0; k < m; k++) {
        for (i = 0; i < m; i++) {
            if (cor0(A[i][k]) != 0) {
                for (j = 0; j < k && cor0(A[i][j]) == 0; j++);
                if (j == k) {
                    break;
                }
            }
        }
        if (i == m)
            break;
        for (j = 0; j < m; j++) {
            if (j != i) {
                coef = A[j][k] / A[i][k];
                for (y = 0; y < m; y++) {
                    A[j][y] -= coef * A[i][y];
                }
                for (y = 0; y < m; y++) {
                    B[j][y] -= coef * B[i][y];
                }
            }
        }
    }
    if (k == m) {
        for (k = 0; k < m; k++) {
            for (i = 0; cor0(A[i][k]) == 0; i++);
            for (j = 0; j < m; j++) {
                printf("%lg ", cor0(B[i][j] / A[i][k]));
            }
            if (k != m - 1) {
                printf("\n");
            }
        }
    } else {
        printf("NO\n");
    }
    for (i = 0; i < m; i++)
        free(A[i]);
    free(A);
    for (i = 0; i < m; i++)
        free(B[i]);
    free(B);
    return 0;
}
