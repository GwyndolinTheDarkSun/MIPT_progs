#include <stdio.h>
#include <stdlib.h>

typedef struct {
    unsigned num;
    unsigned address;
    unsigned length;
} segment;

int main() {
    unsigned X, N, i, k, a, b;
    segment *A;
    scanf("%u%u", &X, &N);
    A = (segment *)malloc(N * sizeof(segment));
    k = 12; /* с 12 более ли менее очевидно , 32 - 10 - 10 ( потому что размер в MB)) */
    while (X > 1) {
        X = X >> 1;
        k--;
    }
    a = 1 << k;
    for (i = 0; i < N; i++) {
        scanf("%u%x%x", &A[i].num, &A[i].address, &A[i].length);
    }
    printf("%u %u\n", k, a);
    while (scanf("%x", &b) == 1) {
        a = b >> (32 - k);
        b = b & ((1 << (32 - k)) - 1);
        printf("%u:0x%x -> ", a, b);
        for (i = 0; i < N && A[i].num != a; i++);
        if (i != N && b < A[i].length) {
            printf("0x%x\n", b + A[i].address);
        } else {
            puts("error");
        }
    }
    free(A);
    return 0;
}
