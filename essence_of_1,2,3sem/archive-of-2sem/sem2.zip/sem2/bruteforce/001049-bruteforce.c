int bruteforce(char *buf, unsigned n) {
    unsigned a, j;
    for (a = 0; a < n; a++)
        buf[a] = '\0';
    if (n == 1) {
        return check(buf);
    }
    a = 0;
    if (!check(buf)) {
        buf[0] = START_CHAR;
        while (a < n - 1 && !check(buf)) {
            buf[0]++;
            for (j = 0; j < a && buf[j] == STOP_CHAR + 1; j++) {
                buf[j + 1]++;
                buf[j] = START_CHAR;
            }
            if (buf[a] == STOP_CHAR + 1) {
                buf[a] = START_CHAR;
                a++;
                if (a < n - 1) {
                    buf[a] = START_CHAR;
                }
            }
        }
    }
    if (a < n - 1) {
        return 1;
    } else {
        return 0;
    }
}