#include <stdio.h>
#include <stdlib.h>

int Determinant (int **A, int m, int curr, int last) {
    int i, j, k, l, znak;
    int **D, sum;
    if (curr == m - 1) {
        if (last == -1) {
            return A[0][0];
        }
        if (last == 0) {
            return A[1][1];
        } else {
            return A[1][0];
        }
    }
    D = (int**)malloc((m - curr) * sizeof(int*));
    for (i = 0; i < m - curr; i++) {
        D[i] = (int*)malloc((m - curr) * sizeof(int));
    }
    sum = 0;
    if (last == -1) {
        for (i = 0; i < m - curr; i++) {
            for (j = 0; j < m - curr; j++) {
                D[i][j] = A[i][j];
            }
        }
    } else {
        for (i = 1; i < m - curr + 1; i++) {
            l = 0;
            for (j = 0; j < m - curr + 1; j++) {
                if (j != last) {
                    D[i - 1][l] = A[i][j];
                    l++;
                }
            }
        }
    }
    znak = 1;
    for (i = 0; i < m - curr; i++) {
        sum += znak * D[0][i] * Determinant(D, m , curr + 1, i);
        znak = -znak;
    }
    for (i = 0; i < m - curr; i++)
        free(D[i]);
    free(D);
    return sum;
}

int main() {
    int m, i, j, curr, last;
    int **A;
    scanf("%d", &m);
    A = (int**)malloc(m * sizeof(int*));
    for (i = 0; i < m; i++) {
        A[i] = (int*)malloc(m * sizeof(int));
        for (j = 0; j < m; j++) {
            scanf("%d", &A[i][j]);
        }
    }
    printf("%d\n", Determinant(A, m, 0, -1));
    for (i = 0; i < m; i++)
        free(A[i]);
    free(A);
    return 0;
}
