#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#define cor0(x) ((x) > -1e-6 && (x) < 1e-6 ? 0 : (x))

int main() {
    int m, i, j, counTi, y, mark1, mark2, k;
    double **A,  c, S, coef;
    scanf("%d", &m);
    mark1 = 0;
    counTi = 0;
    A = (double**)malloc(m * sizeof(double*));
    for (i = 0; i < m; i++) {
        A[i] = (double*)malloc(m * sizeof(double));
        for (j = 0; j < m; j++) {
            scanf("%lg", &A[i][j]);
        }
    }
    for (k = 0; k < m; k++) {
        mark2 = 0;
        i = 0;
        while (mark2 == 0 && i != m) {
            if (A[i][k] != 0) {
                mark2 = 1;
                for (j = 0; j < k; j++) {
                    if (A[i][j] != 0) {
                        mark2 = 0;
                    }
                }
            }
            i++;
        }
        i--;
        if (i == m - 1 && mark2 == 0) {
            mark1 = 1;
        }
        if (mark1 == 0) {
            for (j = 0; j < m; j++) {
                if (j != i) {
                    coef = A[j][k] / A[i][k];
                    for (y = 0; y < m; y++) {
                        A[j][y] = cor0(A[j][y] - coef * A[i][y]);
                    }
                }
            }
        }
    }
    S = 1;
    if (mark1 == 0) {
        for (k = 0; k < m; k++) {
            i = 0;
            while (A[i][k] == 0) {
                i++;
            }
            if (i == k)
                S *= A[i][k];
            else {
                S *= A[i][k];
                counTi ++;
            }
        }
        if (counTi >= 2) {
            counTi--;
        }
        if (counTi % 2 == 0 || ((counTi + 1) / 2) % 2 == 0) {
            printf("%lg\n", cor0(S));
        } else {
            printf("%lg\n", cor0(-S));
        }
    } else {
        printf("0\n");
    }

    for (i = 0; i < m; i++)
        free(A[i]);
    free(A);
    return 0;
}
