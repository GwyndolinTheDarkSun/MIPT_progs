#include <stdio.h>
#include <stdlib.h>

double Determinant (double **A, int m, int curr, int last) {
    int i, j, k, l, znak;
    double **D, sum;
    D = (double**)malloc((m - curr) * sizeof(double*));
    for (i = 0; i < m - curr; i++) {
        D[i] = (double*)malloc((m - curr) * sizeof(double));
    }
    k = 0;
    l = 0;
    sum = 0;
    if (last == -1) {
        for (i = 0; i < m - curr; i++) {
            for (j = 0; j < m - curr; j++) {
                D[i][j] = A[i][j];
            }
        }
    } else {
        for (i = 1; i < m - curr + 1; i++) {
            for (j = 0; j < m - curr + 1; j++) {
                if (j != last) {
                    D[k][l] = A[i][j];
                    l++;
                }
            }
            k++;
            l = 0;
        }
    }
    if (curr == m - 1) {
        j = D[0][0];
        for (i = 0; i < m - curr; i++)
            free(D[i]);
        free(D);
        return j;
    }
    znak = 1;
    for (i = 0; i < m - curr; i++) {
        last = i;
        sum += znak * D[0][i] * Determinant(D, m , curr + 1, last);
        znak = -znak;
    }
    for (i = 0; i < m - curr; i++)
        free(D[i]);
    free(D);
    return sum;
}
int main() {
    int m, i, j, curr, last;
    double **A;
    scanf("%d", &m);
    A = (double**)malloc(m * sizeof(double*));
    for (i = 0; i < m; i++) {
        A[i] = (double*)malloc(m * sizeof(double));
        for (j = 0; j < m; j++) {
            scanf("%lg", &A[i][j]);
        }
    }
    curr = 0;
    last = -1;
    printf("%lg\n", Determinant(A, m, curr, last));
    for (i = 0; i < m; i++)
        free(A[i]);
    free(A);
    return 0;
}
