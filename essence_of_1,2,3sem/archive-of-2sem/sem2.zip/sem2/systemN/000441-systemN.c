#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#define cor0(x) ((x) > -1e-6 && (x) < 1e-6 ? 0 : (x))

double Determinant(double **A, int m, double *C, int t) {
    int k, mark2, mark1, i, j, y, counTi;
    double S, **B, coef;
    mark1 = 0;
    counTi = 0;
    S = 1;
    B = (double**)malloc(m * sizeof(double*));
    for (i = 0; i < m; i++) {
        B[i] = (double*)malloc(m * sizeof(double));
        for (j = 0; j < m; j++) {
            B[i][j] = A[i][j];
        }
    }
    if (t != -1) {
        for (i = 0; i < m; i++) {
            B[i][t] = C[i];
        }
    }
    for (k = 0; k < m; k++) {
        mark2 = 0;
        i = 0;
        while (mark2 == 0 && i != m) {
            if (B[i][k] != 0) {
                mark2 = 1;
                for (j = 0; j < k; j++) {
                    if (B[i][j] != 0) {
                        mark2 = 0;
                    }
                }
            }
            i++;
        }
        i--;
        if (i == m - 1 && mark2 == 0) {
            mark1 = 1;
        }
        if (mark1 == 0) {
            for (j = 0; j < m; j++) {
                if (j != i) {
                    coef = B[j][k] / B[i][k];
                    for (y = 0; y < m; y++) {
                        B[j][y] = cor0(B[j][y] - coef * B[i][y]);
                    }
                }
            }
        }
    }
    if (mark1 == 0) {
        for (k = 0; k < m; k++) {
            i = 0;
            while (B[i][k] == 0) {
                i++;
            }
            if (i == k)
                S *= B[i][k];
            else {
                S *= B[i][k];
                counTi ++;
            }
        }
        if (counTi >= 2) {
            counTi--;
        }
        if (counTi % 2 == 0 || ((counTi + 1) / 2) % 2 == 0) {
            S = cor0(S);
        } else {
            S = cor0(-S);
        }
    } else {
        S = 0;
    }
    for (i = 0; i < m; i++)
        free(B[i]);
    free(B);
    return S;
}
int main() {
    int m, i, j;
    double **A, *C, determinant1;
    scanf("%d", &m);
    A = (double**)malloc(m * sizeof(double*));
    C = (double*)malloc(m * sizeof(double));
    for (i = 0; i < m; i++) {
        A[i] = (double*)malloc(m * sizeof(double));
        for (j = 0; j < m; j++) {
            scanf("%lg", &A[i][j]);
        }
        scanf("%lg", &C[i]);
    }
    determinant1 = Determinant(A, m, C, -1);
    if (determinant1 != 0) {
        for (i = 0; i < m; i++) {
            printf("%lg\n", cor0(Determinant(A, m, C, i) / determinant1));
        }
    } else {
        printf("NO\n");
    }
    for (i = 0; i < m; i++)
        free(A[i]);
    free(A);
    free(C);
    return 0;
}

