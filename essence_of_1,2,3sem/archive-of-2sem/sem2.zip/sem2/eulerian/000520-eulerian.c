#include <stdio.h>

int main() {
    int A[100][100];
    int i, j, N, s;
    scanf("%d", &N);
    for (i = 0; i < N; i++) {
        s = 0;
        for (j = 0; j < N; j++) {
            scanf("%d", &A[i][j]);
            if (i != j)
                s += A[i][j];
        }
        if (s % 2 != 0) {
            puts("NO");
            return 0;
        }
    }
    puts("YES");
    return 0;
}
