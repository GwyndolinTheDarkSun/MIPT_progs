#include <stdio.h>
#include <stdlib.h>

int main() {
    unsigned N, i, *A, t, j;
    scanf("%u", &N);
    A = (unsigned *)malloc(N * sizeof(unsigned));
    for (i = 0; i < N; i++)
        scanf("%X", &A[i]);
    scanf("%X", &t);
    j = t >> 26;
    if (j >= 0 && j < N) {
        t = (t << 6) >> 6;
        A[j] += t;
        printf("%X\n", A[j]);
    } else {
        puts("error");
    }
    free(A);
    return 0;
}
