#include <stdio.h>
#include <stdlib.h>

struct structure {
    unsigned num;
    unsigned adres;
};
int main() {
    unsigned X, N, i, k, a, b;
    struct structure *A;
    scanf("%u %u", &X, &N);
    A = (struct structure *)malloc(N * sizeof(struct structure));
    k = 13; /* так как исходный размер дан в MB , то переходя к байтам от 32 отнимаем 20 ,
             остается 12 байт ; от 12 нужно отнять значение наибольшей степени в двоийной записи X,
             но тогда мы отнимаем на один раз больше нужного в цикле ниже , так как также считается 0 бит , тогда отнимаем от 13*/
    while (X > 0) {
        X = X >> 1;
        k--;
    }
    a = 1;
    a = a << k;
    for (i = 0; i < N; i++) {
        scanf("%u%x", &A[i].num, &A[i].adres);
    }
    printf("%u %u\n", k, a);
    while (scanf("%x", &b) == 1) {
        a = b >> (32 - k);
        b = b & ((1 << (32 - k)) - 1);
        printf("%u.0x%x -> ", a, b);
        for (i = 0; i < N && A[i].num != a; i++);
        if (i != N) {
            printf("0x%x\n", b + A[i].adres);
        } else {
            puts("error");
        }
    }
    free(A);
    return 0;
}